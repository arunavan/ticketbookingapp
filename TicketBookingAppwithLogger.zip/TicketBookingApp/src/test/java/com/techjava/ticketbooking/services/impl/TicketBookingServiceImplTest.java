package com.techjava.ticketbooking.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TicketBookingServiceImplTest {

	@Test
	void testFindTicketByEmail() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAllTickets() {
		fail("Not yet implemented");
	}

	@Test
	void testFindTicketById() {
		
		fail("Not yet implemented");
	}

	@Test
	void testUpdateEmailById() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteTicketById() {
		fail("Not yet implemented");
	}

	@Test
	void testCreateTicket() {
		fail("Not yet implemented");
	}

}
